let colors = ['#70d6ff', '#ff70a6', '#ff9770', '#ffd670', '#89ED8D']
let maxIndex

function setup() {
  let w = min(windowWidth, windowHeight)
  createCanvas(w, w)
  blendMode(MULTIPLY)
  rectMode(CENTER)

  maxIndex = 6
}

function draw() {
  background('white')
  drawFractal(width / 2, width / 2, width * fxrandom(0.1, 0.5), 0)
  noLoop()
  fxpreview()
}

function drawFractal(x, y, radius, index) {
  if (index > maxIndex) return
  let r = floor(fxrandom(0, 1) * 5)
  let c = colors[r]
  // let c = colors[index % 5]

  fill(c)
  noStroke()
  if (index > 0) square(x, y, radius * 1)
  let offset = fxrandom(0, width * 0.2)
  let factor = fxrandom(0.45, 0.55)
  index++
  drawFractal(x - radius + fxrandom(-offset, offset), y + fxrandom(-offset, offset), radius * factor, index)
  drawFractal(x + radius + fxrandom(-offset, offset), y + fxrandom(-offset, offset), radius * factor, index)
  drawFractal(x + fxrandom(-offset, offset), y - radius + fxrandom(-offset, offset), radius * factor, index)
  drawFractal(x + fxrandom(-offset, offset), y + radius + fxrandom(-offset, offset), radius * factor, index)
}

function fxrandom(a, b) {
  return a + fxrand() * (b - a)
}
